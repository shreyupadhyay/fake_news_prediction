# CS 224W Final Project

## Setup

Data: download zip files [here](https://www.dropbox.com/sh/449oc54l89dwu55/AACMm0x62-JBdZJ6GV_EMdkza?dl=0)
